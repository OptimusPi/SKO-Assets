Help


Stick Knights Online - Beta

This game is in open beta stage. It can be considered in development however accounts you create will NOT be lost or wiped. This readme can help you play the game until the proper help items are added in-game


------Movement------
arrow keys - walk
space -jump



------Attacking------
Alt - punch or slash weapon



--------Menus--------
click menus to use them



--Player Interation--
click players to interact



-------Trading-------
interact with player and invite to trade
click increments to offer items
right click items to offer



--------Shops--------
click shops to use them
click [buy/sell] to switch mode
click increment to shange offering mode
click 'ok' to make a transaction


--------Rules--------
see rules.txt file or website


-------Contact-------
IRC CHAT: http://www.optimuspi.net/IRC/
Website: http://www.stickknightsonline.com/



